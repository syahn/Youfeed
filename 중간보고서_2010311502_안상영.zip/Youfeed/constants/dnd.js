export default {
  WIDGET: 'WIDGET'
};
