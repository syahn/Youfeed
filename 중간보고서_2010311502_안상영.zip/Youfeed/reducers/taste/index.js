
/* eslint-disable */
export const taste = (state = { interest: 'Programming' }, action = {}) => state;
