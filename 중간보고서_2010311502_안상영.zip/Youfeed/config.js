export const firebaseConfig = {
  apiKey: "AIzaSyDfvH44yIqsIl45VmV8dfbH90jF3ybH-QE",
  authDomain: "youfeed-aca14.firebaseapp.com",
  databaseURL: "https://youfeed-aca14.firebaseio.com",
  storageBucket: "youfeed-aca14.appspot.com",
  messagingSenderId: "658536204674"
};

export const feedlyConfig = {
  userId: "ae0d870e-b5de-4be2-bdc7-4c0951ff0aeb",
  accessToken: "A06EprS0187tNdGMJ1XPTVQa1eE8SeGLXZeK3GZy2UwZ8qzOGSqZlPmXNcYul0zueeQRLI4P33GbF8vr6fWgPusOHS_UpNzfJ3eLRLg2bJKjAl15kXDdal3uJn5STFRLsLh9aLpP7_PEVZ9IwZhkrJw21eabhWzhzO-9r0OkXBesU_0Kscpb4SaRPW4TpYpfGimsnBivZzPELZ8_4kONEsJWsMF-Mg:feedlydev",
};

export const superfeedrConfig = {
  login: 'Frankahn',
  token: '84a7ae219672104d9a8641093444ca2f'
};

export const behanceConfig = {
  key: 'aGKdIP0yb7YmWlW26UhnJczF4Vx8UlLR'
};

export const dribbleConfig = {
  accessToken: '3da719d0b673e20c483853b77b8bf4402ca49d03270f7df7d42a60aeba64ad72'
};
